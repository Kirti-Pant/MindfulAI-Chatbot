/*
  # Create therapists database

  1. New Tables
    - `therapists`
      - `id` (uuid, primary key)
      - `name` (text)
      - `specialty` (text)
      - `rating` (numeric)
      - `address` (text)
      - `phone` (text)
      - `website` (text, nullable)
      - `availability` (text)
      - `location_city` (text)
      - `location_state` (text)
      - `location_zip` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `therapists` table
    - Add policy for authenticated users to read therapist data
    - Add policy for admin users to manage therapist data
*/

CREATE TABLE IF NOT EXISTS therapists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  specialty text NOT NULL,
  rating numeric NOT NULL CHECK (rating >= 0 AND rating <= 5),
  address text NOT NULL,
  phone text NOT NULL,
  website text,
  availability text NOT NULL,
  location_city text NOT NULL,
  location_state text NOT NULL,
  location_zip text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE therapists ENABLE ROW LEVEL SECURITY;

-- Allow read access to all authenticated users
CREATE POLICY "Allow read access to all authenticated users"
  ON therapists
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow full access to admin users (you'll need to set up admin roles)
CREATE POLICY "Allow full access to admin users"
  ON therapists
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Create indexes for better search performance
CREATE INDEX IF NOT EXISTS therapists_location_city_idx ON therapists (location_city);
CREATE INDEX IF NOT EXISTS therapists_location_state_idx ON therapists (location_state);
CREATE INDEX IF NOT EXISTS therapists_location_zip_idx ON therapists (location_zip);